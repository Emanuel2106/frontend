export const SiteProps = {
    appName: 'Universidad Surcolombiana',
    drawerWidth: 240,
    urlbase: "http://localhost:8081/agrodev/api",
    urldinamica: "http://localhost:8081/uscoia/api/v1"
    
}

