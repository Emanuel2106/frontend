import React, { useEffect, useState } from 'react';
import { Button, Grid, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Typography, TablePagination, Box } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { getAllPersonas, deletePersona } from './personaServiceFile';
import FormPersona from './FormPersona';

export default function GridPersona({ onAdd, onEdit, goBack }) { 
  const [personas, setPersonas] = useState([]);
  const [openForm, setOpenForm] = useState(false);
  const [personaToEdit, setPersonaToEdit] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(3);

  useEffect(() => {
    fetchPersonas();
  }, []);

  const fetchPersonas = async () => {
    const personasData = await getAllPersonas();
    setPersonas(personasData);
  };

  const handleDelete = async (id) => {
    await deletePersona(id);
    fetchPersonas();
  };

  const handleAdd = () => {
    setPersonaToEdit(null);
    setOpenForm(true);
  };

  const handleEdit = (persona) => {
    setPersonaToEdit(persona);
    setOpenForm(true);
  };

  const handleCloseForm = () => {
    setOpenForm(false);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  return (
    <Grid container spacing={2}>
      <Grid item xs={12} style={{ position: 'sticky', top: 0, zIndex: 1000, backgroundColor: '#fff', paddingTop: '20px', paddingBottom: '10px', boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.1)' }}>
        <Grid container alignItems="center">
          <Grid item xs={12} sm={6}>
            <Typography variant="h5" align="left" style={{ margin: '0 0 10px 0' }}>
              Gestión de Personas
            </Typography>
          </Grid>
          <Grid item xs={12} sm={3} style={{ marginBottom: '10px' }}>
            <Button
              variant="contained"
              onClick={goBack}
              startIcon={<ArrowBackIcon />}
              sx={{
                backgroundColor: '#90CAF9',
                color: 'black',
                '&:hover': {
                  backgroundColor: '#64B5F6',
                },
                borderRadius: '12px',
                padding: '8px 16px',
                fontSize: '16px',
                fontWeight: 'bold',
                width: '100%',
              }}
            >
              VOLVER
            </Button>
          </Grid>
          <Grid item xs={12} sm={3} style={{ marginBottom: '10px', textAlign: 'right' }}>
            <Button
              variant="contained"
              color="primary"
              onClick={handleAdd}
              sx={{
                borderRadius: '12px',
                padding: '8px 16px',
                fontSize: '16px',
                fontWeight: 'bold',
              }}
            >
              ADD
            </Button>
          </Grid>
        </Grid>
      </Grid>
      
      {/* Tabla con margen reducido */}
      <Grid item xs={12} style={{ overflowY: 'auto' }}>
        <TableContainer component={Paper} style={{ overflowX: 'auto' }}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Tipo Identificación</TableCell>
                <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Identificación</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Apellido</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Nombre</TableCell>
                <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Género</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Fecha Nacimiento</TableCell>
                <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Estrato</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Dirección</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Celular</TableCell>
                <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Estado</TableCell>
                <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Acciones</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {personas.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((persona) => (
                <TableRow key={persona.per_id}>
                  <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.tipoIdentificacion}</TableCell>
                  <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.identificacion}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.apellido}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.nombre}</TableCell>
                  <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.genero}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.fechaNacimiento}</TableCell>
                  <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.estrato}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.direccion}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.celular}</TableCell>
                  <TableCell style={{ maxWidth: '100px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{persona.estado}</TableCell>
                  <TableCell style={{ maxWidth: '150px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    <Button variant="outlined" color="primary" onClick={() => handleEdit(persona)}>Update</Button>
                    <Button variant="outlined" color="secondary" onClick={() => handleDelete(persona.per_id)} style={{ marginLeft: '8px' }}>Delete</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Grid>

      {/* Paginación con margen superior reducido */}
      <Grid item xs={12}>
        <Box display="flex" justifyContent="flex-end" mt={0}>
          <TablePagination
            rowsPerPageOptions={[3, 5, 10]}
            component="div"
            count={personas.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Grid>
      <FormPersona 
        open={openForm} 
        onClose={handleCloseForm} 
        personaToEdit={personaToEdit} 
        fetchPersonas={fetchPersonas} 
      />
    </Grid>
  );
}
